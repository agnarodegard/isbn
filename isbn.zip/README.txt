2015-02-06 1006
Field groups works programmatically.
field_group not added to profile yet.
Started looking into options_onoff, see .module for testing.

2015-02-05 1116
Code cleanup.

2015-02-05 1033
Almost all fields are in. Missing: "godkjent", and new: title field for "curriculum type".
All existing fields have correctly set #states via conditional_fields.
Hierarchy works.
Starting work on theming.


2015-01-30 1456
Did a detour trying to implement #state myself. Decided to use conditonal_fields instead.
This module will now, so far at least, only install fields and nothing else.

2015-01-26 1459
Fields moved from node to multifield.
Multifield has cardinality -1.
Added field_pid and field_weight as value fields with widget type text.
Onwards to test form #state!

2015-01-26 initial commit
Works:
create node type advpensum
create taxonomies kull, months
create fields
create instances
