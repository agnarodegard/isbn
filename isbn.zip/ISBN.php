<?php
namespace Emweb\ISBN;

class ISBN {
  public function __construct() {

  }
  public function getIsbn() {
    return $this->isbn;
  }
}
